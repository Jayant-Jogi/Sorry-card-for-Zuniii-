Zuniii Direct Sorry Card

Upload ONLY index.html and cat.gif to the root of your GitHub Pages repository.
Do not open index.html from the phone file manager. Use the GitHub Pages URL.
The Open my sorry button uses a direct inline click handler so it works reliably on mobile browsers.
